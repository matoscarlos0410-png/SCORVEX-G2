const $=id=>document.getElementById(id);
const canvas=$("game"),ctx=canvas.getContext("2d");
let audioOn=true,audioCtx=null,game=null,last=0;

const saveKey="scorvex_save_v2";
const defaults=()=>({level:1,score:0,coins:0,xp:0,maxHp:100,hp:100,maxEnergy:100,energy:100,damage:18,speed:260,weapon:"BLADE",kills:0,wave:1,zone:1,best:0});
function load(){try{return {...defaults(),...JSON.parse(localStorage.getItem(saveKey))}}catch{return defaults()}}
function save(){if(game)localStorage.setItem(saveKey,JSON.stringify({...game.stats,best:Math.max(game.stats.best,game.stats.score)}))}
let stats=load();

function beep(freq=440,duration=.06,type="sine"){
 if(!audioOn)return;
 try{audioCtx??=new (window.AudioContext||window.webkitAudioContext)();let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.value=.035;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+duration);o.stop(audioCtx.currentTime+duration)}catch{}
}
function startAudio(){if(audioCtx?.state==="suspended")audioCtx.resume()}

function newGame(keep=false){
 stats=keep?load():defaults();
 game={
  player:{x:550,y:325,r:18,cd:0,skill:0,inv:0},
  enemies:[],bullets:[],particles:[],drops:[],keys:{},running:true,paused:false,
  spawn:0,kills:stats.kills,combo:0,comboTimer:0,missionGoal:5,boss:null
 };
 $("menu").classList.remove("active");$("gameScreen").classList.add("active");resizeCanvas();beep(180,.12,"sawtooth");
 updateHUD(); requestAnimationFrame(loop);
}
function resizeCanvas(){/* canvas internal resolution stays stable for consistent gameplay */}
function addEnemy(type="normal"){
 let side=Math.floor(Math.random()*4),x=side<2?Math.random()*1100:(side===2?0:1100),y=side<2?(side?650:0):Math.random()*650;
 let lvl=stats.level;
 let e={x,y,r:type==="boss"?42:type==="elite"?25:17,type,hp:type==="boss"?420+lvl*60:type==="elite"?70+lvl*12:34+lvl*5,max:type==="boss"?420+lvl*60:type==="elite"?70+lvl*12:34+lvl*5,speed:type==="boss"?55:type==="elite"?85:105,cd:0,hit:0};
 game.enemies.push(e); if(type==="boss"){game.boss=e;$("bossUI").classList.remove("hidden");$("bossName").textContent="OVERLORD "+stats.level}}
function burst(x,y,n=8){
 for(let i=0;i<n;i++){let a=Math.random()*Math.PI*2,s=40+Math.random()*150;game.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.45+Math.random()*.45})}
}
function attack(){
 let p=game.player;if(p.cd>0||game.paused)return;
 p.cd=.22;beep(240,.05,"square");
 let near=game.enemies.filter(e=>Math.hypot(e.x-p.x,e.y-p.y)<95).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];
 if(near){near.hp-=stats.damage;near.hit=.1;game.combo++;game.comboTimer=1.5;burst(near.x,near.y,4);beep(520,.05,"triangle");if(near.hp<=0)killEnemy(near)}
}
function skill(){
 let p=game.player;if(p.skill>0||stats.energy<25||game.paused)return;
 p.skill=2.5;stats.energy-=25;beep(80,.18,"sawtooth");
 for(const e of game.enemies){let d=Math.hypot(e.x-p.x,e.y-p.y);if(d<180)e.hp-=stats.damage*2.2}
 burst(p.x,p.y,28);game.enemies.slice().forEach(e=>{if(e.hp<=0)killEnemy(e)})
}
function killEnemy(e){
 let i=game.enemies.indexOf(e);if(i<0)return;
 game.enemies.splice(i,1);game.kills++;stats.kills++;stats.score+=e.type==="boss"?1000:e.type==="elite"?250:100;stats.coins+=e.type==="boss"?120:e.type==="elite"?35:10;stats.xp+=e.type==="boss"?180:e.type==="elite"?35:12;burst(e.x,e.y,e.type==="boss"?30:12);beep(e.type==="boss"?90:330,.08,"square");
 if(e.type==="boss"){game.boss=null;$("bossUI").classList.add("hidden");stats.zone++;stats.level++;stats.xp=0;stats.maxHp+=20;stats.maxEnergy+=10;stats.hp=stats.maxHp;stats.energy=stats.maxEnergy}
 while(stats.xp>=stats.level*100){stats.xp-=stats.level*100;stats.level++;stats.maxHp+=8;stats.maxEnergy+=5;stats.damage+=2;stats.hp=stats.maxHp;stats.energy=stats.maxEnergy}
 if(game.kills%game.missionGoal===0){stats.score+=300;stats.coins+=50;game.missionGoal+=5;beep(720,.15)}
 save();updateHUD();
}
function update(dt){
 if(game.paused)return;
 let p=game.player,k=game.keys;
 let dx=(k.d||k.ArrowRight?1:0)-(k.a||k.ArrowLeft?1:0),dy=(k.s||k.ArrowDown?1:0)-(k.w||k.ArrowUp?1:0);
 if(dx||dy){let m=Math.hypot(dx,dy);p.x+=dx/m*stats.speed*dt;p.y+=dy/m*stats.speed*dt}
 p.x=Math.max(25,Math.min(1075,p.x));p.y=Math.max(25,Math.min(625,p.y));p.cd=Math.max(0,p.cd-dt);p.skill=Math.max(0,p.skill-dt);p.inv=Math.max(0,p.inv-dt);
 stats.energy=Math.min(stats.maxEnergy,stats.energy+8*dt);game.comboTimer-=dt;if(game.comboTimer<=0)game.combo=0;
 game.spawn-=dt;
 if(game.spawn<=0 && game.enemies.length<Math.min(12,4+stats.level)){addEnemy(Math.random()<.15?"elite":"normal");game.spawn=Math.max(.35,1.15-stats.level*.05)}
 if(stats.kills>0&&stats.kills%15===0&&game.enemies.length<3&&!game.boss)addEnemy("boss");
 for(const e of game.enemies){
  let ax=p.x-e.x,ay=p.y-e.y,d=Math.hypot(ax,ay)||1;e.x+=ax/d*e.speed*dt;e.y+=ay/d*e.speed*dt;e.cd=Math.max(0,e.cd-dt);e.hit=Math.max(0,e.hit-dt);
  if(d<e.r+p.r+4&&e.cd<=0&&p.inv<=0){stats.hp-=e.type==="boss"?12:6;e.cd=e.type==="boss"?1:.7;p.inv=.45;beep(110,.06,"sawtooth");if(stats.hp<=0){stats.hp=stats.maxHp;stats.score=Math.max(0,stats.score-200);stats.coins=Math.max(0,stats.coins-20);game.enemies=[];}}
 }
 for(const b of game.particles){b.x+=b.vx*dt;b.y+=b.vy*dt;b.vx*=.96;b.vy*=.96;b.life-=dt}
 game.particles=game.particles.filter(b=>b.life>0);
 updateHUD();
}
function draw(){
 ctx.clearRect(0,0,1100,650);
 let g=ctx.createLinearGradient(0,0,1100,650);g.addColorStop(0,"#050a1b");g.addColorStop(1,"#101032");ctx.fillStyle=g;ctx.fillRect(0,0,1100,650);
 ctx.strokeStyle="#152448";ctx.globalAlpha=.7;for(let x=0;x<1100;x+=50){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,650);ctx.stroke()}for(let y=0;y<650;y+=50){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(1100,y);ctx.stroke()}ctx.globalAlpha=1;
 for(const e of game.enemies){ctx.beginPath();ctx.arc(e.x,e.y,e.r+5,0,7);ctx.fillStyle=e.type==="boss"?"#ff315d33":e.type==="elite"?"#9c5cff33":"#27dfff22";ctx.fill();ctx.beginPath();ctx.arc(e.x,e.y,e.r,0,7);ctx.fillStyle=e.hit>0?"#fff":"#ff405e";ctx.fill();ctx.strokeStyle="#ffb3c0";ctx.stroke();ctx.fillStyle="#080b18";ctx.fillRect(e.x-e.r*.5,e.y-2,e.r,e.r*.25);ctx.fillStyle="#55edff";ctx.fillRect(e.x-e.r*.5,e.y-2,e.r*(e.hp/e.max),e.r*.25)}
 let p=game.player;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(performance.now()/500);ctx.beginPath();ctx.moveTo(0,-25);ctx.lineTo(18,15);ctx.lineTo(0,9);ctx.lineTo(-18,15);ctx.closePath();ctx.fillStyle="#46e8ff";ctx.shadowBlur=25;ctx.shadowColor="#24dcff";ctx.fill();ctx.restore();
 ctx.fillStyle="#bff8ff";ctx.font="bold 11px Arial";ctx.textAlign="center";ctx.fillText(stats.weapon,p.x,p.y+34);
 for(const b of game.particles){ctx.globalAlpha=Math.max(0,b.life);ctx.fillStyle="#54eaff";ctx.beginPath();ctx.arc(b.x,b.y,3,0,7);ctx.fill()}ctx.globalAlpha=1;
 if(game.paused){ctx.fillStyle="#02040acc";ctx.fillRect(0,0,1100,650);ctx.fillStyle="#fff";ctx.font="bold 42px Arial";ctx.fillText("PAUSA",550,310)}
}
function loop(t){if(!game)return;let dt=Math.min(.033,(t-last)/1000||.016);last=t;update(dt);draw();if(game.running)requestAnimationFrame(loop)}
function updateHUD(){
 $("level").textContent=stats.level;$("score").textContent=stats.score;$("coins").textContent=stats.coins;$("combo").textContent=game?.combo||0;
 $("hpText").textContent=`${Math.max(0,Math.round(stats.hp))} / ${stats.maxHp}`;$("energyText").textContent=`${Math.round(stats.energy)} / ${stats.maxEnergy}`;
 $("hpBar").style.width=Math.max(0,stats.hp/stats.maxHp*100)+"%";$("energyBar").style.width=Math.max(0,stats.energy/stats.maxEnergy*100)+"%";$("xpBar").style.width=Math.min(100,stats.xp/(stats.level*100)*100)+"%";
 $("missionText").textContent=`Elimina ${game?.missionGoal||5} enemigos`;$("missionProgress").textContent=`${stats.kills % (game?.missionGoal||5)} / ${game?.missionGoal||5}`;
 $("zoneName").textContent=`SECTOR ${String(stats.zone).padStart(2,"0")}`;$("waveText").textContent=`OLEADA ${stats.wave}`;
 $("bestScore").textContent=Math.max(stats.best||0,stats.score);
 if(game?.boss)$("bossBar").style.width=Math.max(0,game.boss.hp/game.boss.max*100)+"%";
}
function modal(title,body){$("modalTitle").textContent=title;$("modalBody").innerHTML=body;$("modal").classList.remove("hidden")}
$("playBtn").onclick=()=>{startAudio();newGame(false)};
$("continueBtn").onclick=()=>{startAudio();newGame(true)};
$("controlsBtn").onclick=()=>modal("CONTROLES",`<div class="control-grid"><div>W A S D / Flechas<br><small>Mover</small></div><div>ESPACIO<br><small>Atacar</small></div><div>E<br><small>Habilidad especial</small></div><div>P / botón PAUSA<br><small>Pausar</small></div><div>🛒 MEJORAS<br><small>Comprar mejoras</small></div><div>🎯 Objetivo<br><small>Completa misiones y derrota jefes</small></div></div>`);
$("shopBtn").onclick=()=>{if(!game)return;modal("MEJORAS",`<div class="shop-item"><span>❤️ Botiquín<small>Recupera 40 HP</small></span><button data-buy="heal">40 💰</button></div><div class="shop-item"><span>⚔️ Núcleo de ataque<small>+5 daño</small></span><button data-buy="damage">80 💰</button></div><div class="shop-item"><span>🛡️ Armadura<small>+25 HP máximo</small></span><button data-buy="hp">100 💰</button></div><div class="shop-item"><span>⚡ Reactor<small>+20 energía máxima</small></span><button data-buy="energy">90 💰</button></div>`);document.querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>buy(b.dataset.buy))};
function buy(type){let cost={heal:40,damage:80,hp:100,energy:90}[type];if(stats.coins<cost){beep(80,.1);return}stats.coins-=cost;if(type==="heal")stats.hp=Math.min(stats.maxHp,stats.hp+40);if(type==="damage")stats.damage+=5;if(type==="hp"){stats.maxHp+=25;stats.hp=stats.maxHp}if(type==="energy"){stats.maxEnergy+=20;stats.energy=stats.maxEnergy}save();updateHUD();beep(700,.08);$("modal").classList.add("hidden")}
$("closeModal").onclick=()=>$("modal").classList.add("hidden");$("modal").onclick=e=>{if(e.target===$("modal"))$("modal").classList.add("hidden")};
$("pauseBtn").onclick=()=>{if(!game)return;game.paused=!game.paused};$("menuBtn").onclick=()=>{if(game)save();game=null;$("gameScreen").classList.remove("active");$("menu").classList.add("active")};
$("soundBtn").onclick=()=>{audioOn=!audioOn;$("soundBtn").textContent=audioOn?"🔊 SONIDO":"🔇 SONIDO";if(audioOn)startAudio()};
window.addEventListener("keydown",e=>{if(!game)return;game.keys[e.key]=true;if(e.key===" ")attack();if(e.key.toLowerCase()==="e")skill();if(e.key.toLowerCase()==="p")game.paused=!game.paused});
window.addEventListener("keyup",e=>{if(game)game.keys[e.key]=false});
updateHUD();
